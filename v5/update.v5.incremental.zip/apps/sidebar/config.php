<?php
$_CONF['app_name'] = 'Sidebar';
$_CONF['app_desc'] = 'Baut (falls aktiviert) eine Sidebar mit beliebigem Inhalt auf der Seite ein';
$_CONF['base_file'] = 'sidebar.php';
$_CONF['type'] = 'static';
$_CONF['general_conf'] = 'genConf.php';
$_CONF['install'] = 'install.php';