<?php
$_CONF['app_name'] = 'Meta';
$_CONF['app_desc'] = 'Sorgt dafür, das Metadaten auf der Homepage angezeigt werden.';
$_CONF['menu_top'] = '';
$_CONF['base_file'] = 'meta.php';
$_CONF['type'] = 'static';
$_CONF['general_conf'] = 'genConf.php';
$_CONF['install'] = 'install.php';
?>